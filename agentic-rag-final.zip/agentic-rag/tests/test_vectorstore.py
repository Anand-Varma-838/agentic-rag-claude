"""Tests for chunking and vectorstore logic (no API keys needed)."""

import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from vectorstore import chunk_text, DocumentChunk


def test_chunk_basic():
    text = " ".join(["word"] * 500)
    chunks = chunk_text(text, source="test.txt")
    assert len(chunks) > 1
    for c in chunks:
        assert isinstance(c, DocumentChunk)
        assert len(c.text) > 0


def test_chunk_short_text():
    text = "Too short"
    chunks = chunk_text(text, source="test.txt")
    # A very short text might produce 0 or 1 chunks but no errors
    assert isinstance(chunks, list)


def test_chunk_preserves_source():
    text = " ".join(["word"] * 100)
    chunks = chunk_text(text, source="myfile.pdf", page=3)
    for c in chunks:
        assert c.source == "myfile.pdf"
        assert c.page == 3


def test_chunk_overlap():
    text = " ".join([f"word{i}" for i in range(1000)])
    chunks = chunk_text(text, source="test.txt")
    # With overlap, last word of chunk N should appear near start of chunk N+1
    if len(chunks) >= 2:
        last_words = set(chunks[0].text.split()[-10:])
        first_words = set(chunks[1].text.split()[:10])
        assert len(last_words & first_words) > 0


def test_document_chunk_metadata():
    c = DocumentChunk("some text", source="doc.pdf", page=5, chunk_index=2)
    meta = c.metadata()
    assert meta["source"] == "doc.pdf"
    assert meta["page"] == 5
    assert meta["chunk_index"] == 2


def test_document_chunk_unique_ids():
    c1 = DocumentChunk("text", source="a.txt")
    c2 = DocumentChunk("text", source="a.txt")
    assert c1.id != c2.id
