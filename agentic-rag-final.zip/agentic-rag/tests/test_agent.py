"""Tests for safe_eval, ToolExecutor, and AgentTracer (no API keys needed)."""

import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from agent import safe_eval, ToolExecutor
from tracer import AgentTracer


# ---------------------------------------------------------------------------
# safe_eval
# ---------------------------------------------------------------------------

def test_addition():
    assert safe_eval("2 + 2") == 4

def test_subtraction():
    assert safe_eval("10 - 3") == 7

def test_multiplication():
    assert safe_eval("6 * 7") == 42

def test_division():
    assert abs(safe_eval("10 / 4") - 2.5) < 1e-9

def test_power():
    assert safe_eval("2 ** 10") == 1024

def test_compound():
    result = safe_eval("(152 - 134) / 134 * 100")
    assert abs(result - 13.4328) < 0.01

def test_round():
    assert safe_eval("round(3.14159, 2)") == 3.14

def test_rejects_import():
    with pytest.raises(Exception):
        safe_eval("__import__('os')")

def test_rejects_string_ops():
    with pytest.raises(Exception):
        safe_eval("'a' + 'b'")

def test_rejects_list():
    with pytest.raises(Exception):
        safe_eval("[1, 2, 3]")


# ---------------------------------------------------------------------------
# ToolExecutor
# ---------------------------------------------------------------------------

class MockRetriever:
    def retrieve(self, query, top_k=4):
        return [{"text": f"Mock result for: {query}", "metadata": {"source": "mock.pdf", "page": 1}}]

    def format_context(self, results):
        if not results:
            return "No relevant documents found."
        return "\n".join(f"[{i+1}] Source: {r['metadata']['source']}\n{r['text']}"
                         for i, r in enumerate(results))

    class vector_store:
        @staticmethod
        def get_all():
            return [{"text": "mock doc", "metadata": {"source": "mock.pdf", "page": 1}}]


@pytest.fixture
def executor():
    return ToolExecutor(retriever=MockRetriever())


def test_search_returns_result(executor):
    result = executor.execute("search_documents", {"query": "revenue"})
    assert "revenue" in result
    assert "mock.pdf" in result


def test_search_respects_top_k(executor):
    result = executor.execute("search_documents", {"query": "test", "top_k": 2})
    assert isinstance(result, str)


def test_calculate_basic(executor):
    result = executor.execute("calculate", {"expression": "10 * 5"})
    assert "50" in result


def test_calculate_percentage(executor):
    result = executor.execute("calculate", {"expression": "(200 - 150) / 150 * 100"})
    assert "33" in result


def test_calculate_invalid(executor):
    result = executor.execute("calculate", {"expression": "import os"})
    assert "error" in result.lower()


def test_list_sources(executor):
    result = executor.execute("list_sources", {})
    assert "mock.pdf" in result


def test_unknown_tool(executor):
    result = executor.execute("nonexistent", {})
    assert "Unknown" in result


# ---------------------------------------------------------------------------
# AgentTracer
# ---------------------------------------------------------------------------

def test_log_tool_call():
    t = AgentTracer()
    step = t.log_tool_call("search_documents", {"query": "test"}, "some result", 42.0)
    assert step.tool_name == "search_documents"
    assert step.step_num == 1
    assert len(t.steps) == 1


def test_log_final_answer():
    t = AgentTracer()
    t.log_tool_call("calculate", {"expression": "1+1"}, "2")
    t.log_final_answer("The answer is 2.")
    assert t.steps[-1].action == "final_answer"
    assert len(t.steps) == 2


def test_summary():
    t = AgentTracer()
    t.log_tool_call("search_documents", {}, "r1")
    t.log_tool_call("calculate", {}, "r2")
    t.log_final_answer("done")
    s = t.summary()
    assert s["tool_calls"] == 2
    assert "search_documents" in s["tools_used"]
    assert "calculate" in s["tools_used"]


def test_reset():
    t = AgentTracer()
    t.log_tool_call("search_documents", {}, "r")
    t.reset()
    assert t.steps == []
    assert t._counter == 0


def test_step_to_dict():
    t = AgentTracer()
    step = t.log_tool_call("calculate", {"expression": "2+2"}, "4", 10.5)
    d = step.to_dict()
    assert d["tool"] == "calculate"
    assert d["duration_ms"] == 10.5
    assert d["action"] == "tool_call"
    assert "result_preview" in d
