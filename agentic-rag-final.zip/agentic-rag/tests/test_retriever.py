"""Tests for HybridRetriever — BM25, RRF, and formatting (no API keys needed)."""

import sys
from pathlib import Path
import pytest

sys.path.insert(0, str(Path(__file__).parent.parent / "src"))

from retriever import HybridRetriever


# ---------------------------------------------------------------------------
# Minimal mock so we don't need ChromaDB in tests
# ---------------------------------------------------------------------------

SAMPLE_DOCS = [
    {"text": "Revenue in Q3 was $152 million, up from $134 million in Q2.", "metadata": {"source": "report.pdf", "page": 1}},
    {"text": "Operating costs increased by 8% year over year due to hiring.", "metadata": {"source": "report.pdf", "page": 2}},
    {"text": "The company expanded into three new markets in Southeast Asia.", "metadata": {"source": "strategy.pdf", "page": 1}},
    {"text": "Key risks include supply chain disruption and currency fluctuation.", "metadata": {"source": "report.pdf", "page": 5}},
    {"text": "Customer satisfaction scores reached an all-time high of 92%.", "metadata": {"source": "survey.txt", "page": 0}},
]


class MockVectorStore:
    def __init__(self, docs):
        self._docs = docs

    def search(self, query: str, top_k: int = 10):
        return [
            {"text": d["text"], "metadata": d["metadata"], "score": 0.9 - i * 0.05}
            for i, d in enumerate(self._docs[:top_k])
        ]

    def get_all(self):
        return self._docs

    def count(self):
        return len(self._docs)


@pytest.fixture
def retriever():
    store = MockVectorStore(SAMPLE_DOCS)
    r = HybridRetriever(vector_store=store)
    r.build_bm25_index()
    return r


# ---------------------------------------------------------------------------
# BM25 tests
# ---------------------------------------------------------------------------

def test_bm25_finds_relevant_doc(retriever):
    results = retriever._bm25_search("revenue Q3", top_k=3)
    assert len(results) > 0
    top = results[0]["text"].lower()
    assert "revenue" in top or "q3" in top


def test_bm25_returns_empty_on_no_match(retriever):
    results = retriever._bm25_search("zzzzzz nonsense xyz", top_k=3)
    # Scores all zero → should return empty list
    assert isinstance(results, list)


def test_bm25_respects_top_k(retriever):
    results = retriever._bm25_search("the", top_k=2)
    assert len(results) <= 2


# ---------------------------------------------------------------------------
# RRF tests
# ---------------------------------------------------------------------------

def test_rrf_deduplicates():
    semantic = [{"text": "doc A"}, {"text": "doc B"}]
    keyword  = [{"text": "doc A"}, {"text": "doc C"}]
    merged = HybridRetriever._reciprocal_rank_fusion(semantic, keyword)
    texts = [d["text"] for d in merged]
    assert len(texts) == len(set(texts))


def test_rrf_boosts_overlap():
    semantic = [{"text": "shared"}, {"text": "only semantic"}]
    keyword  = [{"text": "shared"}, {"text": "only keyword"}]
    merged = HybridRetriever._reciprocal_rank_fusion(semantic, keyword)
    # "shared" should rank first since it appears in both lists
    assert merged[0]["text"] == "shared"


# ---------------------------------------------------------------------------
# format_context tests
# ---------------------------------------------------------------------------

def test_format_context_includes_source(retriever):
    results = retriever.vector_store.search("revenue", top_k=2)
    ctx = retriever.format_context(results)
    assert "Source:" in ctx
    assert "report.pdf" in ctx


def test_format_context_empty(retriever):
    ctx = retriever.format_context([])
    assert "No relevant" in ctx


def test_format_context_numbers_results(retriever):
    results = retriever.vector_store.search("revenue", top_k=3)
    ctx = retriever.format_context(results)
    assert "[1]" in ctx
